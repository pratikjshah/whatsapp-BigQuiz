self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1e753a57e2eadc4a7ae1e886b26a20ca",
    "url": "/index.html"
  },
  {
    "revision": "71bd33958d05e092e329",
    "url": "/static/js/2.c3fd06a0.chunk.js"
  },
  {
    "revision": "083376eb39a6341c9cd5",
    "url": "/static/js/main.f22622fb.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "eb71b14209960e6ab7752661334099b8",
    "url": "/static/media/bg.eb71b142.png"
  },
  {
    "revision": "1bc77022f259abe803fc73f21565530a",
    "url": "/static/media/error.1bc77022.svg"
  },
  {
    "revision": "1daab8f1117f6b6ce27b764c92dffa27",
    "url": "/static/media/random-shapes.1daab8f1.svg"
  },
  {
    "revision": "570e52acff687d03ea7b8489664fad75",
    "url": "/static/media/whatsapp-chat-example.570e52ac.zip"
  }
]);